package day2ass;

public class StaticMethod {
	int x=20;
	static int y=40;
	static void Accessingstatic() {
		//x is not accessable
		//System.out.println("value of x=" +x);
		System.out.println("value of y=" +y);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StaticMethod s1=new StaticMethod();
		s1.Accessingstatic();	}

}
