package day2ass;

public class MethodOverriding {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Parent m1=new child();
		m1.display();
	}

}
