package day2ass;

public class InstanceMethod {
	int a=10;
	static int b=35;
	 void Accessing() {
		 //Accessing a and b
		System.out.println("value of a=" +a);
		System.out.println("value of b=" +b);
	}
	 public static void main(String[] args) {
				// TODO Auto-generated method stub
				InstanceMethod i1=new InstanceMethod();
				i1.Accessing();
	}
}
