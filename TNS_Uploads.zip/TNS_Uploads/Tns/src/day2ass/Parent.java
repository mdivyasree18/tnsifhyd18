package day2ass;

public class Parent {
	int a=10;
	static int b=20;
	void display() {
		System.out.println("value of a=" +a);
	}
	static void show() {
		System.out.println("value of b=" +b);
	}
	

}
