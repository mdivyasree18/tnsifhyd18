package day2ass;

public class InsStaMethodOverriding {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Parent p1=new child();
		
		//instance method can override
		p1.display();
		
		//static method can't override
		p1.show();
	}

}
 