package day2ass;

public class InsStaMethodOverloading {
	int sum(int a,int b) {
		return a+b;
	}
	static double sum(double a,double b) {
	return a+b;	
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InsStaMethodOverloading i1=new InsStaMethodOverloading();
		System.out.println("sum of integers ="+ i1.sum(1,2));
		System.out.println("sum of floating num =" +i1.sum(3.5,2.5));


	}

}
