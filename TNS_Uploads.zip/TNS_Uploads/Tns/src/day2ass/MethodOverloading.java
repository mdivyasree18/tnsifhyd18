package day2ass;

public class MethodOverloading {
	//int a,b;
	int sum(int a,int b) {
		return a+b;
	}
	double sum(double a,double b) {
		return a+b;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MethodOverloading m1=new MethodOverloading();
		System.out.println(m1.sum(3,4));
		System.out.println(m1.sum(3.5, 4.5));

	}

}
