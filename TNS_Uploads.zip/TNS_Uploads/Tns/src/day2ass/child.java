package day2ass;

public class child extends Parent{
	int c=30;
	static int d=40;
	void display() {
		System.out.println("value of c=" +c);
	}
	static void show() {
		System.out.println("value of d=" +d);
	}

}
