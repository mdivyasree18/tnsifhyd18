package assignments;

public class Approach2 {
	String batsman="virat kohli";
	static String bowler="Bumrah";
	void display() {
		System.out.println("Bumrah takes wicket");
	}
static String display1() {
	return "virat hits century";

}

}
