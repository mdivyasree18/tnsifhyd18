package assignments;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Approach2 n1=new Approach2();
		System.out.println(n1.batsman);
		System.out.println(Approach2.bowler);
		n1.display();
		System.out.println(Approach2.display1());


	}

}
