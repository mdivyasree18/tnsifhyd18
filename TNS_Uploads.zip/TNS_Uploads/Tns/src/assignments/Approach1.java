package assignments;


public class Approach1 {
	String batsman="virat kohli";
	static String bowler="Bumrah";
	void display() {
		System.out.println("Bumrah takes wicket");
	}
static String display1() {
	return "virat hits century";
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Approach1 i1=new Approach1();
		System.out.println(i1.batsman);
		System.out.println(Approach1.bowler);
		i1.display();
		System.out.println(Approach1.display1());

	}

}
