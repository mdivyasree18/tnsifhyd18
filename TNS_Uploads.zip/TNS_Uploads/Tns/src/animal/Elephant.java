package animal;

public class Elephant {
	public void eat() {
		System.out.println("Elephant is eating");
	}
	public void sound() {
		System.out.println("Elephant trumpeting");
	}
	public void sleep() {
		System.out.println("Elephant is Sleeping");
	}

}
