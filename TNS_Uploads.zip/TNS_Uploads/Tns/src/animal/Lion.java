package animal;

public class Lion {
	public void eat() {
		System.out.println("Lion is eating");
	}
	public void sound() {
		System.out.println("Lion is Roaring");
	}
	public void sleep() {
		System.out.println("Lion is Sleeping");
	}

}
