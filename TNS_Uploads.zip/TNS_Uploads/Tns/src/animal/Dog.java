package animal;

public class Dog {
	public void eat() {
		System.out.println("Dog is eating");
	}
	public void sound() {
		System.out.println("Dog is Barking");
	}
	public void sleep() {
		System.out.println("Dog is Sleeping");
	}
}
