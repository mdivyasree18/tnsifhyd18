package casestudy;
import animal.*;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dog d=new Dog();
		Lion l=new Lion();
		Elephant e=new Elephant();
		
		//accessing Dog class methods
		d.eat();
		d.sound();
		d.sleep();
		
		//accessing Lion class methods
		l.eat();
		l.sound();
		l.sleep();
		
		//accessing Elephant class methods
		e.eat();
		e.sound();
		e.sleep();
		

	}

}
