package day3ass;

public class MultilevelInheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Derived1 s2=new Derived1();
		
		//Accessing Base class method
		s2.show();
		
		//Accessing Derived class method
		s2.print();
		
		//Accessing Derived1 Class method
		s2.display();

	}

}
