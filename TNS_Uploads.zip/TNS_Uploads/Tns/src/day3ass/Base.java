package day3ass;

public class Base {
	void show() {
		System.out.println("base method called");
	}

}
