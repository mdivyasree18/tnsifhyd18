package day3ass;

public class SingleInheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Derived s1=new Derived();
		
		//Base class method
		s1.show();
		
		//Derived class method
		s1.print();

	}

}
