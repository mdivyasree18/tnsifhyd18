package day3ass;

public class HierarchicalInheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Derived obj1=new Derived();
		Derived2 obj2=new Derived2();
		
		//Accessing Base class method
		obj1.show();
		
		//Accessing Derived class method
		obj1.print();
		
		//Accessing Base class method
		obj2.show();
		
		//Accessing Derived2 class method
		obj2.display();

	}

}
