package day3ass;

public class Derived1 extends Derived {
void display() {
	System.out.println("Derived1 method called");
}
}
