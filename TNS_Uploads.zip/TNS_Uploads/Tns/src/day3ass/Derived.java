package day3ass;

public class Derived extends Base {
	void print() {
		System.out.println("Derived method called");
	}

}
