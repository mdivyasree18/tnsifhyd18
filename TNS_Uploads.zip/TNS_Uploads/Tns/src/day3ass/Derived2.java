package day3ass;

public class Derived2 extends Base {
	void display() {
		System.out.println("Derived2 method called");
	}

}
