/**
 * 
 */
/**
 * 
 */
module jdbcMinorProject {
	requires java.sql;
}