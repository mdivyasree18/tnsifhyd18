package minorproject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InsertData {
	public static void main(String[] args) {
		
	
	String dbURL = "jdbc:mysql://localhost:3306/employeedb";
	String username = "root";
	String password = "divya18";
		 
		try {
		 
		    Connection conn = DriverManager.getConnection(dbURL, username, password);
		    String sql = "INSERT INTO employee(name, password, fullname, email,address) VALUES (?, ?, ?, ?, ?)";
		    
		    PreparedStatement statement = conn.prepareStatement(sql);
		    statement.setString(1, "srujana");
		    statement.setString(2, "divya123");
		    statement.setString(3, "Divya sree");
		    statement.setString(4, "divya@microsoft.com");
		    statement.setString(5, "Hyderabad");
		     
		    int rowsInserted = statement.executeUpdate();
		    if (rowsInserted > 0) {
		        System.out.println("A new user was inserted successfully!");
		    }
		} catch (SQLException ex) {
		    ex.printStackTrace();
		}
	    
	}
}
